// Agent.cc

#include <iostream>
#include "Agent.h"

using namespace std;

Agent::Agent ()
{

}

Agent::~Agent ()
{

}

void Agent::Initialize ()
{

}

Action Agent::Process (Percept& percept)
{
	char c;
	Action action;
	bool validAction = false;

	while (!validAction)
	{
		validAction = true;

		if (percept.Bump) {
			action = TURNLEFT;
		} else if (percept.Glitter) {
			action = GRAB;
		} else if (percept.Stench) {
			action = SHOOT;
		} else if (percept.Scream) {
			action = CLIMB;
		} else 
			action = GOFORWARD;
	}

	return action;
}

void Agent::GameOver (int score)
{

}

