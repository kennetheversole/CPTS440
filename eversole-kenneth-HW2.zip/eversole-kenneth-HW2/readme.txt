This is the readme for Kenneth Eversole's HW2 assignment.


This project is sum what working, but I am little confused Dr. Holders Orienation class and what we could get from it.

I also have permission from him to submbit this assignment late, I have an email if there is any confusion.